export class DocumentDetails{
documentId: number = 1;
}
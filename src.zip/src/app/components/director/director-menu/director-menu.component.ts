import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-director-menu',
  templateUrl: './director-menu.component.html',
  styleUrls: ['./director-menu.component.css']
})
export class DirectorMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
